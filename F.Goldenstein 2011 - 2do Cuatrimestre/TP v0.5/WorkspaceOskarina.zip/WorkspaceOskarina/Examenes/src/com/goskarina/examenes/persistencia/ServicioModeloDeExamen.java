package com.goskarina.examenes.persistencia;

public class ServicioModeloDeExamen {

}
