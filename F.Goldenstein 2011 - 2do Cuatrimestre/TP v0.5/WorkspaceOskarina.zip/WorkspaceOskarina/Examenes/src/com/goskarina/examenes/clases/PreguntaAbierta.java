package com.goskarina.examenes.clases;

public class PreguntaAbierta extends Pregunta {

}
