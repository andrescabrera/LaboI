import com.goskarina.examenes.clases.Alumno;
import com.goskarina.examenes.gui.ListadoAlumnos;
import com.goskarina.examenes.persistencia.ServiceException;
import com.goskarina.examenes.persistencia.ServicioAlumno;


public class Principal {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ListadoAlumnos listadoAlumnos = new ListadoAlumnos();
		listadoAlumnos.setVisible(true);
		
	}
}
