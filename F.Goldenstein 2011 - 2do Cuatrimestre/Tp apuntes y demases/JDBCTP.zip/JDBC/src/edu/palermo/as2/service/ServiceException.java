/*
 * Created on 19/05/2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package edu.palermo.as2.service;

/**
 * @author Claudioz
 */
public class ServiceException extends Exception {
	
	public ServiceException(String msg) {
		super(msg);
	}
}
